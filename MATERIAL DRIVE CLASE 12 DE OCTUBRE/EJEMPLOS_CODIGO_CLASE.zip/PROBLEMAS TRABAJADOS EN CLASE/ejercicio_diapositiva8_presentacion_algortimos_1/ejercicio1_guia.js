/*
Cree un programa que declare e inicialice una variable para
almacenar los 48.5 dólares que cuesta FIFA18, una variable para
almacenar la letra z y otra para almacenar un estado lógico
verdadero. Imprima cada una de las variables. Haga
pseudocódigo y código.
*/
let precioFifa = 48.5;
let letraZ = 'z';
let estadoLogico = true;

console.log(precioFifa);
console.log(letraZ);
console.log(estadoLogico);



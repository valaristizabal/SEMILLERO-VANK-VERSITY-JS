//constante edad
//usamos const en lugar de let
const edad = 19;
const gravedad = 9.8;
const password = "123456";
/*
Cree un programa que tome la base y la 
altura de un triángulo e imprima su área.
PASOS A SEGUIR
1. pedir la base y al altura del triangulo
2. aplicamos la formula de area del triangulo: b * a / 2
3. usamos console.log() para mostrar la salida
*/
//ENTRADA DE DATOS
let base = parseFloat(prompt("Ingrese base"));
let altura = parseFloat(prompt("Ingrese altura"));
//PROCESO
let area = base * altura / 2;
//salida
console.log("El area es: ", area);
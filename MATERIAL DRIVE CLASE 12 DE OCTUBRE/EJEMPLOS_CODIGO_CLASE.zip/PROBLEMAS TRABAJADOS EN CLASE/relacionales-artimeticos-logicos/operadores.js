//relacionales
let resultado = 3 < 1;
console.log(resultado);
let nombres = "pepe" == "pepe";
console.log(nombres);
let color = "Azul" == "azul";
console.log(color);
let mayorEdad = 20 >= 18;
console.log(mayorEdad);
let numeros = 10 >= 10;
console.log(numeros);
let cantidad = 2 <= 2;
console.log(cantidad);
let diferente = 4 != 5;
console.log(diferente);
let noDiferente = 3 != 3;
console.log(noDiferente);

//operadores lógicos
//operador Y (&&)
let logico1 = 3 < 5 && 5 == 5;
console.log(logico1);
let logico2 = 3 == 3 && 4 < 1*1;
console.log(logico2);
//operador 0 (||)
let logico3 = 3 == 3 || 4 < 1*1;
console.log(logico3);
let logico4 = 3*1 < 1 || 3 != 3;
console.log(logico4);
//negacion
let negacion1 = !3>1;
console.log(negacion1);
let negacion2 = ! 20 < 10;
console.log(negacion2);
















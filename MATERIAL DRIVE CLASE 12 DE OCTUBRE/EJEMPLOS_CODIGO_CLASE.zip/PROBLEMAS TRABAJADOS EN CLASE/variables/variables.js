//los nombres de las variables no pueden
//empezar por numeros ni tener espacios
//notación camelCase
//variable entera
let edadUsuarioPlataforma = 20;
//variable flotante o real
let estatura = 1.65;
//caracter
let numeral = '#';
//cadena de caracteres
let mensaje = "Somos VankVersity";
//variable lógica
let casado = false;

//declaración de variable
let puntos;
//inicializando la variable
puntos = 300;
//declaración e inicialización en una línea
let nombre = "Programador VankVersity";
//imprimir una variable
console.log(nombre);
